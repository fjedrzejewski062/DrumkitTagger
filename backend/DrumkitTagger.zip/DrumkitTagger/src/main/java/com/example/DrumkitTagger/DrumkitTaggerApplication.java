package com.example.DrumkitTagger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrumkitTaggerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrumkitTaggerApplication.class, args);
	}

}
